import * as validate_form from './validate_form.js'

validate_form()
const get_menus = document.querySelectorAll('nav>ul>li');
const menus = Array.from(get_menus);

// menus.map(li => li.innerHTML="need to add a listener")
