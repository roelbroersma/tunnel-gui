#!/usr/bin/bash
#THIS SCRIPT IS WILL REBOOT THE DEVICE

/usr/bin/reboot
